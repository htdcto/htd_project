//
//  ViewController.m
//  demo
//
//  Created by piupiupiu on 16/7/29.
//  Copyright © 2016年 haitudeng. All rights reserved.
//

#import "ViewController.h"
#import "AVFoundation/AVFoundation.h"
#import "AudioToolBox/AudioToolBox.h"


@interface ViewController ()

@end
AVAudioPlayer *_playMusic;//背景音乐
SystemSoundID _sound;//音效
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self isHeadsetPluggedIn];
    //
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)backMusic
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
    NSString *path = [[NSBundle mainBundle]pathForResource:@"lalala.mp3" ofType:nil];
    //2)将路径字符串转换为url:注意是从哪里获取，如果是从本地获取用下面的，([NSURL URLWithString:path](从网络上获取))
   
   // 3)找到路径，初始化音频播放器(_playMusic定义的全局变量)
    _playMusic = [[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:path] error:nil];
 
   /* 4)设置播放器属性
    设置循环播放的次数
    循环次数为0,播放一次
    循环次数为1，播放两次
    循环次数为负数时，播放无限循环
    */
    [_playMusic setNumberOfLoops:-1];
    //5)播放之前调用方法,准备播放
    [_playMusic prepareToPlay];
    [_playMusic play];
  /*  背景音乐完成播放
    2.添加音效
    1)加载音效
    */
    
}
- (BOOL)isHeadsetPluggedIn {
    UInt32 dataSize;
    CFStringRef currentRoute;
    currentRoute = NULL;
    dataSize = sizeof(CFStringRef);
    AudioSessionInitialize(NULL, NULL, NULL, NULL);
    AudioSessionGetProperty(kAudioSessionProperty_AudioRoute, &dataSize, &currentRoute);
        if([(__bridge NSString  *) currentRoute hasPrefix: @"Headphone"])
        {
            [self backMusic];
    }
        else{
            

        }
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
