//
//  MainTableViewCell.m
//  cn.Ta.HaiTuDeng.com
//
//  Created by htd on 16/7/21.
//  Copyright © 2016年 haitudeng. All rights reserved.
//

#import "MainTableViewCell.h"

@implementation MainTableViewCell

-(void)loadDataFromModel:(HearModel *)model
{
    
}

- (void)awakeFromNib {
    [super awakeFromNib];

    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
