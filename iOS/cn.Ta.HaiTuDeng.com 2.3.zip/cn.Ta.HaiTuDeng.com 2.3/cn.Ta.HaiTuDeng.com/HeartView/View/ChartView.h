//
//  ChartView.h
//  IOSlineChart
//
//  Created by Apple on 16/5/10.
//  Copyright © 2016年 zhangleishan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChartView : UIView
-(instancetype)initWithFrame:(CGRect)frame :(NSArray *)dataOfDate;

@end
