//
//  ViewController.h
//  cn.Ta.HaiTuDeng.com
//
//  Created by piupiupiu on 16/7/20.
//  Copyright © 2016年 haitudeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
-(void)getLoginServer:(NSString *)name pass:(NSString *)pass;
-(void)didReceiveMemoryWarning;
-(void)didAutoLoginWithError;

@end
