//
//  DetaViewController.h
//  FlowersMan
//
//  Created by 屠夫 on 16/3/11.
//  Copyright (c) 2016年 Soul. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetaViewController : UIViewController

@property (nonatomic,copy)NSString *contentid;


@end
