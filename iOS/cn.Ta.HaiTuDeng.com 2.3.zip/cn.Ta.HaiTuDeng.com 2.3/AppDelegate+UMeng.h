//
//  AppDelegate+UMeng.h
//  cn.Ta.HaiTuDeng.com
//
//  Created by htd on 16/8/29.
//  Copyright © 2016年 haitudeng. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (UMeng)

-(void)setupUMeng;

@end
