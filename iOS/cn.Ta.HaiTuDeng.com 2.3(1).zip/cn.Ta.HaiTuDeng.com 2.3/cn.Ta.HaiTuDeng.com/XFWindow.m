//
//  XFWindow.m
//  cn.Ta.HaiTuDeng.com
//
//  Created by piupiupiu on 16/7/29.
//  Copyright © 2016年 haitudeng. All rights reserved.
//

#import "XFWindow.h"

@implementation XFWindow


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    
}


@end
