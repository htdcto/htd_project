//
//  AYPageControl.h
//  AYPageControl
//
//  Created by Andy on 16/3/28.
//  Copyright © 2016年 Andy. All rights reserved.
//

#ifndef AYPageControl_h
#define AYPageControl_h

#import "AYPageControlView.h"

#endif /* AYPageControl_h */
