//
//  UIView+GetViewController.h
//  php
//
//  Created by 李东旭 on 16/3/10.
//  Copyright © 2016年 李东旭. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (GetViewController)

// 获取当前view所在的ViewController
- (UIViewController *)theViewController;

@end
